"""Bloco 2 - Risco e tamanho: define quanto comprar, stop e alvo."""
import config


def calcular_ordem(preco):
    quantidade = config.VALOR_POR_ORDEM_USDT / preco
    return {
        "quantidade": round(quantidade, 6),
        "preco": preco,
        "stop": round(preco * (1 - config.STOP_PERCENT), 2),
        "alvo": round(preco * (1 + config.ALVO_PERCENT), 2),
    }
