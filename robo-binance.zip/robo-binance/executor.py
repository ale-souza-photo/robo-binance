"""Bloco 3 - Executor: envia ordens à Binance (ou simula).

Com MODO_SIMULADO = True nenhuma ordem real é enviada.
"""
import config


class Executor:
    def __init__(self, exchange):
        self.exchange = exchange

    def comprar(self, ordem):
        if config.MODO_SIMULADO:
            return {"id": "SIMULADO", "preco": ordem["preco"], "quantidade": ordem["quantidade"]}
        r = self.exchange.create_market_buy_order(config.SIMBOLO, ordem["quantidade"])
        preco = r.get("average") or r.get("price") or ordem["preco"]
        return {"id": r["id"], "preco": preco, "quantidade": ordem["quantidade"]}

    def vender(self, quantidade, preco_atual):
        if config.MODO_SIMULADO:
            return {"id": "SIMULADO", "preco": preco_atual}
        r = self.exchange.create_market_sell_order(config.SIMBOLO, quantidade)
        preco = r.get("average") or r.get("price") or preco_atual
        return {"id": r["id"], "preco": preco}
