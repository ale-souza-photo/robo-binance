# Robô Binance (esqueleto)

Plano: Scanner -> Risco e tamanho -> Executor, com Kill switch e Registro.
Roda no PC, começa em modo SIMULADO.

## Como rodar
1. Instale o Python 3.10+ e rode: `pip install -r requirements.txt`
2. Rode: `python main.py` (modo simulado, não envia ordem real)
3. Para parar na hora: crie um arquivo chamado `PARAR.txt` na pasta
4. Veja o histórico em `registro.csv`

## Passar para o real (só depois de dias no simulado)
1. Crie uma chave de API na Binance com permissão SÓ de trade, SEM saque
2. Defina as variáveis `BINANCE_API_KEY` e `BINANCE_API_SECRET` no seu PC
3. Em `config.py`, troque `MODO_SIMULADO = False` e mantenha o valor em ~US$ 10

## Próximos passos
- Trocar a estratégia placeholder do `scanner.py` pela estratégia testada (backtest)
- Respeitar valor mínimo e casas decimais da Binance (`exchange.load_markets()`)
- Gravar a posição aberta em arquivo, para sobreviver a reinício do robô
- Painel simples de acompanhamento
